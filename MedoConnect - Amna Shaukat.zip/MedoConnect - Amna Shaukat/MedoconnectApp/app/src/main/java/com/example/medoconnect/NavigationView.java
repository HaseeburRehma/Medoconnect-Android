package com.example.medoconnect;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class NavigationView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation_view);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomAppBar);

        // Load menu items from XML
        bottomNavigationView.inflateMenu(R.menu.bottom_menu);
        // Set up the bottom navigation view
        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_home) {
                Intent intent = new Intent(NavigationView.this, Home.class);
                startActivity(intent);
                return true;
            } else if (item.getItemId() == R.id.nav_appointments) {

                return true;
            } else if (item.getItemId() == R.id.nav_call) {

                return true;
            } else if (item.getItemId() == R.id.nav_medical_records) {

                return true;
            } else if (item.getItemId() == R.id.nav_profile) {

                return true;
            }
            return false;
        });
    }
}