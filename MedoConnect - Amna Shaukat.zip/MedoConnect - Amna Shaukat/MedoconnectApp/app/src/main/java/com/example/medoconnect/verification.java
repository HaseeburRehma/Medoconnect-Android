package com.example.medoconnect;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class verification extends AppCompatActivity {

    private EditText etDigit1, etDigit2, etDigit3, etDigit4;
    private Button btnVerify, btnResend, btnGetCodeViaCall;
    private TextView tvTimer;
    private CountDownTimer countDownTimer;
    private int remainingSeconds = 30;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification);

        etDigit1 = findViewById(R.id.et_digit1);
        etDigit2 = findViewById(R.id.et_digit2);
        etDigit3 = findViewById(R.id.et_digit3);
        etDigit4 = findViewById(R.id.et_digit4);
        btnVerify = findViewById(R.id.btn_verify);
        btnResend = findViewById(R.id.btn_resend);
        btnGetCodeViaCall = findViewById(R.id.btn_get_code_via_call);
        tvTimer = findViewById(R.id.tv_timer);

        btnVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verifyCode();
            }
        });

        btnResend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resendCode();
            }
        });

        btnGetCodeViaCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCodeViaCall();
            }
        });

        startTimer();
    }

    private void verifyCode() {
        String code = etDigit1.getText().toString()
                + etDigit2.getText().toString()
                + etDigit3.getText().toString()
                + etDigit4.getText().toString();

        // Perform verification logic here
        Toast.makeText(this, "Verification code: " + code, Toast.LENGTH_SHORT).show();
    }

    private void resendCode() {
        // Perform code resending logic here
        Toast.makeText(this, "Code resent", Toast.LENGTH_SHORT).show();
        startTimer();
    }

    private void getCodeViaCall() {
        // Perform logic to get code via call here
        Toast.makeText(this, "Code sent via call", Toast.LENGTH_SHORT).show();
        startTimer();
    }

    private void startTimer() {
        countDownTimer = new CountDownTimer(30000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                remainingSeconds = (int) (millisUntilFinished / 1000);
                updateTimer();
            }

            @Override
            public void onFinish() {
                remainingSeconds = 0;
                updateTimer();
                showResendButton();
            }
        };

        countDownTimer.start();
        updateTimer();
    }

    private void updateTimer() {
        tvTimer.setText(getString(R.string.timer_seconds, remainingSeconds));
        if (remainingSeconds > 0) {
            tvTimer.setVisibility(View.VISIBLE);
            btnResend.setVisibility(View.GONE);
            btnGetCodeViaCall.setVisibility(View.GONE);
        } else {
            tvTimer.setVisibility(View.GONE);
        }
    }

    private void showResendButton() {
        btnResend.setVisibility(View.VISIBLE);
        btnGetCodeViaCall.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }
}
