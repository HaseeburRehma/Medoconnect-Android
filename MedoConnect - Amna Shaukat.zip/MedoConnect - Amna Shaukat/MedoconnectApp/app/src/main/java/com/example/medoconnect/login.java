package com.example.medoconnect;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.content.Intent;

public class login extends AppCompatActivity {

    private EditText phoneNumberInput;
    private EditText passwordInput;
    private Button signInButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        phoneNumberInput = findViewById(R.id.phone_number_input);
        passwordInput = findViewById(R.id.password_input);
        signInButton = findViewById(R.id.sign_in_button);

        Button signInButton = findViewById(R.id.sign_in_button);
        signInButton.setBackgroundColor(Color.parseColor("#00CED1"));

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signIn();
            }
        });
    }

    private void signIn() {
        String phoneNumber = phoneNumberInput.getText().toString();
        String password = passwordInput.getText().toString();

        // Validate
        if (phoneNumber.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Sign in successful", Toast.LENGTH_SHORT).show();

        // Clear the input fields
        phoneNumberInput.setText("");
        passwordInput.setText("");
    }

    public void openSignUpScreen(View view) {
        Intent intent = new Intent(this, signup.class);
        startActivity(intent);
    }
}