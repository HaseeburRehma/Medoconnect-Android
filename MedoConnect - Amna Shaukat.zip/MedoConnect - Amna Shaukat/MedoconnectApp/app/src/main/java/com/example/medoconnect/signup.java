package com.example.medoconnect;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class signup extends AppCompatActivity {

    private EditText fullNameInput;
    private EditText phoneNumberInput;
    private EditText passwordInput;
    private EditText confirmPasswordInput;
    private CheckBox termsCheckbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        fullNameInput = findViewById(R.id.full_name_input);
        phoneNumberInput = findViewById(R.id.phone_number_input);
        passwordInput = findViewById(R.id.password_input);
        confirmPasswordInput = findViewById(R.id.confirm_password_input);
        termsCheckbox = findViewById(R.id.terms_checkbox);

        Button signUpButton = findViewById(R.id.sign_up_button);
        signUpButton.setBackgroundColor(Color.parseColor("#00CED1"));

        signUpButton.setOnClickListener(v -> signUp());
    }

    private void signUp() {
        // input values
        String fullName = fullNameInput.getText().toString();
        String phoneNumber = phoneNumberInput.getText().toString();
        String password = passwordInput.getText().toString();
        String confirmPassword = confirmPasswordInput.getText().toString();
        boolean termsAccepted = termsCheckbox.isChecked();

        // sign up logic - validation
        if (fullName.isEmpty() || phoneNumber.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        } else if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
        } else if (!termsAccepted) {
            Toast.makeText(this, "Please accept the terms and conditions", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Sign Up successful", Toast.LENGTH_SHORT).show();
        }

        // Display a toast message
        Toast.makeText(this, "Sign Up clicked", Toast.LENGTH_SHORT).show();
    }

    public void openSignInScreen(View view) {
        // Start the sign-in activity or navigate to the sign-in page
        Intent intent = new Intent(this, login.class);
        startActivity(intent);
    }
}
