package com.example.medoconnect;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class SplashScreen extends AppCompatActivity {

    private static final int SPLASH_DURATION = 2000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        // Delay execution of the next screen using a Handler
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Start the main activity or next screen
                Intent intent = new Intent(SplashScreen.this, MainActivity.class);
                startActivity(intent);
                finish(); // Finish the splash screen activity
            }
        }, SPLASH_DURATION);

        Intent intent = new Intent(SplashScreen.this, Login1.class);
        startActivity(intent);
        finish();
    }
}
