package com.example.medoconnect;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class wallet extends AppCompatActivity {

    private ImageView backButton;
    private TextView balanceText;
    private double walletBalance = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet);

        balanceText = findViewById(R.id.text_balance);
        backButton = findViewById(R.id.icon_back);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click event for the back button
                navigateToSettings();
            }
        });

        updateBalanceText();
    }

    private void navigateToSettings() {
        // Start the SettingsActivity
        Intent intent = new Intent(wallet.this, MainActivity.class);
        startActivity(intent);
        Toast.makeText(this, "Navigating to Settings", Toast.LENGTH_SHORT).show();
    }

    private void updateBalanceText() {
        balanceText.setText("$" + walletBalance);
    }
}
