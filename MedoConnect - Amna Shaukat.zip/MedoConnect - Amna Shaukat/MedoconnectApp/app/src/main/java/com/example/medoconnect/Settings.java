package com.example.medoconnect;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBar;

import com.google.android.material.navigation.NavigationView;

public class Settings extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private ActionBarDrawerToggle drawerToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        navigationView = findViewById(R.id.nav_view);
        navigationView.inflateMenu(R.menu.main_menu);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }


        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close);

        drawerLayout.addDrawerListener(drawerToggle);
        drawerToggle.syncState();

        drawerToggle.setDrawerIndicatorEnabled(true);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        navigationView.setNavigationItemSelectedListener(item -> {
            // Handle bottom navigation item clicks
            int itemId = item.getItemId();

                if (itemId == R.id.home) {
                    // Handle home button click
                    Toast.makeText(Settings.this, "Home button clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (itemId == R.id.appointment) {
                    // Handle appointments button click
                    Toast.makeText(Settings.this, "Appointments button clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (itemId == R.id.my_profile) {
                    // Handle my profile button click
                    Toast.makeText(Settings.this, "My Profile button clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (itemId == R.id.wallet) {
                    // Handle wallet button click
                    Toast.makeText(Settings.this, "Wallet button clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (itemId == R.id.view_hospitals) {
                    // Handle view hospitals button click
                    Toast.makeText(Settings.this, "View Hospitals button clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (itemId == R.id.settings) {
                    // Handle settings button click
                    Toast.makeText(Settings.this, "Settings button clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (itemId == R.id.are_you_doctor) {
                    // Handle "Are You Doctor" button click
                    Toast.makeText(Settings.this, "Are You Doctor button clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (itemId == R.id.contact_us) {
                    // Handle contact us button click
                    Toast.makeText(Settings.this, "Contact Us button clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (itemId == R.id.health_news) {
                    // Handle health news button click
                    Toast.makeText(Settings.this, "Health News button clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (itemId == R.id.logout) {
                    // Handle logout button click
                    Toast.makeText(Settings.this, "Logout button clicked", Toast.LENGTH_SHORT).show();
                    return true;
                }

                return false;
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (drawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(navigationView)) {
            drawerLayout.closeDrawers();
        } else {
            super.onBackPressed();
        }
    }}