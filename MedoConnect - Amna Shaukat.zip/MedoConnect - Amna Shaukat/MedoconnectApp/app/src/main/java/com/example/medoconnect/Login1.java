package com.example.medoconnect;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import android.graphics.Color;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Login1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login1);

        Button googleButton = findViewById(R.id.google_button);
        googleButton.setBackgroundColor(ContextCompat.getColor(this, android.R.color.white));

        Button gmailButton = findViewById(R.id.gmail_button);
        gmailButton.setBackgroundColor(ContextCompat.getColor(this, android.R.color.white));

        Button signUpPhoneButton = findViewById(R.id.signup_phone_button);
        signUpPhoneButton.setBackgroundColor(ContextCompat.getColor(this, android.R.color.white));

        Button signUpFacebookButton = findViewById(R.id.signup_facebook_button);
        signUpFacebookButton.setBackgroundColor(Color.parseColor("#1877F2"));

        Button signUpEmailButton = findViewById(R.id.signup_email_button);
        signUpEmailButton.setBackgroundColor(ContextCompat.getColor(this, android.R.color.white));


        googleButton.setOnClickListener(v -> {
            Toast.makeText(Login1.this, "Google clicked", Toast.LENGTH_SHORT).show();
            openWebsite("https://www.google.com");
        });

        gmailButton.setOnClickListener(v -> {
            Toast.makeText(Login1.this, "Gmail clicked", Toast.LENGTH_SHORT).show();
            openWebsite("https://mail.google.com");
        });

        signUpPhoneButton.setOnClickListener(v -> {
            Toast.makeText(Login1.this, "Sign up with cell phone clicked", Toast.LENGTH_SHORT).show();
            openWebsite("https://example.com/signup/phone");
        });

        signUpFacebookButton.setOnClickListener(v -> {
            Toast.makeText(Login1.this, "Sign up with Facebook clicked", Toast.LENGTH_SHORT).show();
            openWebsite("https://example.com/signup/facebook");
        });

        signUpEmailButton.setOnClickListener(v -> {
            Toast.makeText(Login1.this, "Sign up with Email clicked", Toast.LENGTH_SHORT).show();
            openWebsite("https://example.com/signup/email");
        });
    }

    public void openSignInScreen(View view) {
        //navigate to the sign-in page
        Intent intent = new Intent(this, login.class);
        startActivity(intent);
    }


    private void openWebsite(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
}
